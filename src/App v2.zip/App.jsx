import React, { useState, useEffect } from 'react';
import { Mail, Phone, MapPin, Github, Linkedin, Globe, Award, Code, Database, Brain, Download, Star, BookOpen } from 'lucide-react';

const SinglePageCV = () => {
  const [scrollY, setScrollY] = useState(0);

  useEffect(() => {
    const handleScroll = () => setScrollY(window.scrollY);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleDownloadCV = () => {
    const urlDrive = 'https://drive.google.com/file/d/1PAGZxXQBVNgMZz64oh61jquIhKlBroXN/view?usp=drive_link';
    const link = document.createElement('a');
    link.href = urlDrive;
    link.target = '_blank';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div style={{
      minHeight: '100vh',
      background: '#0a0e27',
      color: '#e2e8f0',
      fontFamily: 'system-ui, -apple-system, sans-serif',
      position: 'relative'
    }}>
      {/* Floating header */}
      <div style={{
        position: 'fixed',
        top: 0,
        left: 0,
        right: 0,
        background: `rgba(10, 14, 39, ${Math.min(scrollY / 200, 0.95)})`,
        backdropFilter: 'blur(10px)',
        borderBottom: '1px solid rgba(139, 92, 246, 0.2)',
        padding: '1rem 2rem',
        zIndex: 1000,
        transition: 'all 0.3s ease'
      }}>
        <div style={{ maxWidth: '1400px', margin: '0 auto', display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '1rem' }}>
          <div>
            <h1 style={{ margin: 0, fontSize: '1.5rem', fontWeight: 'bold', background: 'linear-gradient(135deg, #a78bfa, #60a5fa)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent' }}>
              Athini Mgagule
            </h1>
            <p style={{ margin: 0, fontSize: '0.875rem', color: '#94a3b8' }}>Software Developer</p>
          </div>
          <button 
            onClick={handleDownloadCV}
            style={{
              background: 'linear-gradient(135deg, #8b5cf6, #3b82f6)',
              border: 'none',
              borderRadius: '8px',
              color: 'white',
              cursor: 'pointer',
              padding: '0.5rem 1.5rem',
              display: 'flex',
              alignItems: 'center',
              gap: '0.5rem',
              fontSize: '0.875rem',
              fontWeight: '600',
              transition: 'all 0.3s ease'
            }}
            onMouseEnter={(e) => e.currentTarget.style.transform = 'scale(1.05)'}
            onMouseLeave={(e) => e.currentTarget.style.transform = 'scale(1)'}
          >
            <Download size={16} />
            Download CV
          </button>
        </div>
      </div>

      {/* Main content */}
      <div style={{ maxWidth: '1400px', margin: '0 auto', padding: '6rem 2rem 3rem' }}>
        
        {/* Hero section */}
        <section style={{ marginBottom: '4rem', textAlign: 'center' }}>
          <div style={{
            width: '120px',
            height: '120px',
            margin: '0 auto 1.5rem',
            background: 'linear-gradient(135deg, #8b5cf6, #3b82f6)',
            borderRadius: '50%',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            fontSize: '2.5rem',
            fontWeight: 'bold',
            boxShadow: '0 0 40px rgba(139, 92, 246, 0.4)'
          }}>
            AM
          </div>
          <p style={{ fontSize: '1.125rem', color: '#cbd5e1', maxWidth: '800px', margin: '0 auto 2rem', lineHeight: '1.8' }}>
            Highly motivated Computer Science graduate passionate about creating impactful solutions. I transform complex technical challenges into user-friendly applications, having successfully led development teams and delivered projects that improve operational efficiency.
          </p>
          
          {/* Contact bar */}
          <div style={{ display: 'flex', justifyContent: 'center', flexWrap: 'wrap', gap: '2rem', marginBottom: '1.5rem' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', color: '#94a3b8' }}>
              <Phone size={16} />
              <span style={{ fontSize: '0.875rem' }}>+27671891052</span>
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', color: '#94a3b8' }}>
              <Mail size={16} />
              <span style={{ fontSize: '0.875rem' }}>athi200308@gmail.com</span>
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', color: '#94a3b8' }}>
              <MapPin size={16} />
              <span style={{ fontSize: '0.875rem' }}>Randburg, Gauteng</span>
            </div>
          </div>

          {/* Social links */}
          <div style={{ display: 'flex', justifyContent: 'center', gap: '1rem' }}>
            <a href="https://linkedin.com/in/athini-mgagule-8b8b362b2" target="_blank" rel="noopener noreferrer"
              style={{ width: '40px', height: '40px', background: '#2563eb', borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center', transition: 'all 0.3s ease' }}
              onMouseEnter={(e) => e.currentTarget.style.transform = 'scale(1.1)'}
              onMouseLeave={(e) => e.currentTarget.style.transform = 'scale(1)'}>
              <Linkedin size={18} color="white" />
            </a>
            <a href="https://github.com/AthiniMgagule" target="_blank" rel="noopener noreferrer"
              style={{ width: '40px', height: '40px', background: '#374151', borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center', transition: 'all 0.3s ease' }}
              onMouseEnter={(e) => e.currentTarget.style.transform = 'scale(1.1)'}
              onMouseLeave={(e) => e.currentTarget.style.transform = 'scale(1)'}>
              <Github size={18} color="white" />
            </a>
            <a href="https://athinimgagule.netlify.app" target="_blank" rel="noopener noreferrer"
              style={{ width: '40px', height: '40px', background: '#0891b2', borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center', transition: 'all 0.3s ease' }}
              onMouseEnter={(e) => e.currentTarget.style.transform = 'scale(1.1)'}
              onMouseLeave={(e) => e.currentTarget.style.transform = 'scale(1)'}>
              <Globe size={18} color="white" />
            </a>
          </div>
        </section>

        {/* Two-column layout */}
        <div style={{ display: 'grid', gridTemplateColumns: window.innerWidth > 1024 ? '1fr 1fr' : '1fr', gap: '3rem' }}>
          
          {/* Left column */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: '3rem' }}>
            
            {/* Experience */}
            <section>
              <h2 style={{ fontSize: '1.5rem', fontWeight: 'bold', marginBottom: '1.5rem', color: '#a78bfa', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                <Code size={24} />
                Experience
              </h2>
              <div style={{
                background: 'linear-gradient(135deg, rgba(139, 92, 246, 0.1), rgba(59, 130, 246, 0.1))',
                padding: '1.5rem',
                borderRadius: '12px',
                border: '1px solid rgba(139, 92, 246, 0.3)'
              }}>
                <div style={{ marginBottom: '0.5rem' }}>
                  <h3 style={{ fontSize: '1.125rem', fontWeight: 'bold', margin: 0 }}>Exam Invigilator</h3>
                  <p style={{ color: '#a78bfa', fontSize: '0.875rem', margin: '0.25rem 0' }}>University of Witwatersrand</p>
                  <p style={{ color: '#94a3b8', fontSize: '0.875rem', margin: 0 }}>02/2024 - 11/2024</p>
                </div>
                <ul style={{ listStyle: 'none', paddingLeft: 0, margin: '1rem 0 0', color: '#cbd5e1' }}>
                  <li style={{ marginBottom: '0.5rem', paddingLeft: '1.5rem', position: 'relative' }}>
                    <span style={{ position: 'absolute', left: 0, color: '#8b5cf6' }}>→</span>
                    Monitored exam environments, ensuring 100% adherence to academic integrity policies
                  </li>
                  <li style={{ paddingLeft: '1.5rem', position: 'relative' }}>
                    <span style={{ position: 'absolute', left: 0, color: '#8b5cf6' }}>→</span>
                    Ensured compliance with university regulations and addressed student concerns
                  </li>
                </ul>
              </div>
            </section>

            {/* Education */}
            <section>
              <h2 style={{ fontSize: '1.5rem', fontWeight: 'bold', marginBottom: '1.5rem', color: '#a78bfa', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                <Award size={24} />
                Education
              </h2>
              <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
                
                <div style={{
                  background: 'linear-gradient(135deg, rgba(139, 92, 246, 0.1), rgba(59, 130, 246, 0.1))',
                  padding: '1.25rem',
                  borderRadius: '12px',
                  border: '1px solid rgba(139, 92, 246, 0.3)'
                }}>
                  <h3 style={{ fontSize: '1rem', fontWeight: 'bold', margin: '0 0 0.25rem' }}>Software Development & Data Analytics</h3>
                  <p style={{ color: '#a78bfa', fontSize: '0.875rem', margin: '0 0 0.25rem' }}>Faith Mangope Technology and Leadership Institute</p>
                  <p style={{ color: '#94a3b8', fontSize: '0.875rem', margin: 0 }}>03/2025 - Present</p>
                </div>

                <div style={{
                  background: 'linear-gradient(135deg, rgba(139, 92, 246, 0.1), rgba(59, 130, 246, 0.1))',
                  padding: '1.25rem',
                  borderRadius: '12px',
                  border: '1px solid rgba(139, 92, 246, 0.3)'
                }}>
                  <h3 style={{ fontSize: '1rem', fontWeight: 'bold', margin: '0 0 0.25rem' }}>BSc Computer Science and Mathematics</h3>
                  <p style={{ color: '#a78bfa', fontSize: '0.875rem', margin: '0 0 0.25rem' }}>University of Witwatersrand</p>
                  <p style={{ color: '#94a3b8', fontSize: '0.875rem', marginBottom: '0.5rem' }}>02/2022 - 11/2024</p>
                  <div style={{
                    background: 'rgba(234, 179, 8, 0.2)',
                    color: '#fde047',
                    padding: '0.25rem 0.75rem',
                    borderRadius: '20px',
                    fontSize: '0.75rem',
                    border: '1px solid rgba(234, 179, 8, 0.3)',
                    display: 'inline-block'
                  }}>
                    Certificate of Merit: Positive Linear Systems III
                  </div>
                </div>

                <div style={{
                  background: 'linear-gradient(135deg, rgba(139, 92, 246, 0.1), rgba(59, 130, 246, 0.1))',
                  padding: '1.25rem',
                  borderRadius: '12px',
                  border: '1px solid rgba(139, 92, 246, 0.3)'
                }}>
                  <h3 style={{ fontSize: '1rem', fontWeight: 'bold', margin: '0 0 0.25rem' }}>National Senior Certificate</h3>
                  <p style={{ color: '#a78bfa', fontSize: '0.875rem', margin: '0 0 0.25rem' }}>Leap Science and Maths School</p>
                  <p style={{ color: '#94a3b8', fontSize: '0.875rem', margin: 0 }}>01/2017 - 12/2021</p>
                </div>
              </div>
            </section>

            {/* Skills */}
            <section>
              <h2 style={{ fontSize: '1.5rem', fontWeight: 'bold', marginBottom: '1.5rem', color: '#a78bfa', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                <Brain size={24} />
                Skills
              </h2>
              <div style={{
                background: 'linear-gradient(135deg, rgba(139, 92, 246, 0.1), rgba(59, 130, 246, 0.1))',
                padding: '1.5rem',
                borderRadius: '12px',
                border: '1px solid rgba(139, 92, 246, 0.3)'
              }}>
                <div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.5rem' }}>
                  {['Java', 'Python', 'JavaScript', 'React', 'Node.js', 'Spring Boot', 'MySQL', 'PostgreSQL', 'SQLite', 'Azure Cloud', 'Data Analytics', 'Agile/Scrum', 'Team Leadership', 'Problem Solving'].map((skill, i) => (
                    <span key={i} style={{
                      padding: '0.375rem 1rem',
                      background: 'rgba(139, 92, 246, 0.2)',
                      color: '#c4b5fd',
                      borderRadius: '20px',
                      fontSize: '0.875rem',
                      border: '1px solid rgba(139, 92, 246, 0.3)'
                    }}>
                      {skill}
                    </span>
                  ))}
                </div>
              </div>
            </section>
          </div>

          {/* Right column */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: '3rem' }}>
            
            {/* Projects */}
            <section>
              <h2 style={{ fontSize: '1.5rem', fontWeight: 'bold', marginBottom: '1.5rem', color: '#a78bfa', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                <Database size={24} />
                Projects
              </h2>
              <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
                
                <div style={{
                  background: 'linear-gradient(135deg, rgba(139, 92, 246, 0.1), rgba(59, 130, 246, 0.1))',
                  padding: '1.25rem',
                  borderRadius: '12px',
                  border: '1px solid rgba(139, 92, 246, 0.3)'
                }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '0.5rem', flexWrap: 'wrap', gap: '0.5rem' }}>
                    <h3 style={{ fontSize: '1.125rem', fontWeight: 'bold', margin: 0 }}>URL Shortener</h3>
                    <span style={{ color: '#94a3b8', fontSize: '0.75rem' }}>08/2025</span>
                  </div>
                  <p style={{ color: '#cbd5e1', fontSize: '0.875rem', margin: '0 0 0.75rem' }}>
                    A tool that shortens long URLs into shareable links with efficient redirection. Simplifies sharing of lengthy URLs and integrates with web apps.
                  </p>
                  <div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.375rem' }}>
                    {['React', 'Spring Boot', 'MySQL'].map((tech, i) => (
                      <span key={i} style={{
                        background: 'rgba(59, 130, 246, 0.2)',
                        color: '#93c5fd',
                        padding: '0.125rem 0.5rem',
                        borderRadius: '12px',
                        fontSize: '0.75rem'
                      }}>{tech}</span>
                    ))}
                  </div>
                </div>

                <div style={{
                  background: 'linear-gradient(135deg, rgba(139, 92, 246, 0.1), rgba(59, 130, 246, 0.1))',
                  padding: '1.25rem',
                  borderRadius: '12px',
                  border: '1px solid rgba(139, 92, 246, 0.3)'
                }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '0.5rem', flexWrap: 'wrap', gap: '0.5rem' }}>
                    <h3 style={{ fontSize: '1.125rem', fontWeight: 'bold', margin: 0 }}>MovieDatabase</h3>
                    <span style={{ color: '#94a3b8', fontSize: '0.75rem' }}>08/2025 — Present</span>
                  </div>
                  <p style={{ color: '#cbd5e1', fontSize: '0.875rem', margin: '0 0 0.75rem' }}>
                    A platform where users can explore movies and TV shows, create personal watchlists, and interact with other users. Designed to make movie discovery and social interaction around media seamless.
                  </p>
                  <div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.375rem' }}>
                    {['React', 'JavaScript'].map((tech, i) => (
                      <span key={i} style={{
                        background: 'rgba(59, 130, 246, 0.2)',
                        color: '#93c5fd',
                        padding: '0.125rem 0.5rem',
                        borderRadius: '12px',
                        fontSize: '0.75rem'
                      }}>{tech}</span>
                    ))}
                  </div>
                </div>

                <div style={{
                  background: 'linear-gradient(135deg, rgba(139, 92, 246, 0.1), rgba(59, 130, 246, 0.1))',
                  padding: '1.25rem',
                  borderRadius: '12px',
                  border: '1px solid rgba(139, 92, 246, 0.3)'
                }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '0.5rem', flexWrap: 'wrap', gap: '0.5rem' }}>
                    <h3 style={{ fontSize: '1.125rem', fontWeight: 'bold', margin: 0 }}>WriteWisp</h3>
                    <span style={{ color: '#94a3b8', fontSize: '0.75rem' }}>03/2024 — Present</span>
                  </div>
                  <p style={{ color: '#cbd5e1', fontSize: '0.875rem', margin: '0 0 0.75rem' }}>
                    A free platform for writers to draft and publish novels. It also offers prompts to spark inspiration. Helps aspiring authors overcome writer's block and share stories with ease.
                  </p>
                  <div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.375rem' }}>
                    {['React', 'Node.js', 'SQLite'].map((tech, i) => (
                      <span key={i} style={{
                        background: 'rgba(59, 130, 246, 0.2)',
                        color: '#93c5fd',
                        padding: '0.125rem 0.5rem',
                        borderRadius: '12px',
                        fontSize: '0.75rem'
                      }}>{tech}</span>
                    ))}
                  </div>
                </div>
              </div>
            </section>

            {/* Certifications */}
            <section>
              <h2 style={{ fontSize: '1.5rem', fontWeight: 'bold', marginBottom: '1.5rem', color: '#a78bfa', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                <BookOpen size={24} />
                Certifications
              </h2>
              <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
                
                <div style={{
                  background: 'linear-gradient(135deg, rgba(139, 92, 246, 0.1), rgba(59, 130, 246, 0.1))',
                  padding: '1.25rem',
                  borderRadius: '12px',
                  border: '1px solid rgba(139, 92, 246, 0.3)'
                }}>
                  <h3 style={{ fontSize: '1rem', fontWeight: 'bold', margin: '0 0 0.25rem' }}>Oracle Certified Associate, Java SE 8 Programmer I</h3>
                  <p style={{ color: '#a78bfa', fontSize: '0.875rem', margin: '0 0 0.5rem' }}>Oracle • 09/2025</p>
                  <p style={{ color: '#94a3b8', fontSize: '0.75rem', fontFamily: 'monospace', marginBottom: '0.5rem' }}>ID: 322052550OCAJSE8</p>
                  <a href="https://catalog-education.oracle.com/ords/certview/sharebadge?id=8E6A46D55B62EE21AA9563A9B75C5EC6FA9EFB7BB67BD9C3DFE7C877697009C4"
                    target="_blank" rel="noopener noreferrer"
                    style={{ color: '#a78bfa', textDecoration: 'none', fontSize: '0.875rem', fontWeight: '500' }}
                    onMouseEnter={(e) => e.currentTarget.style.color = '#c4b5fd'}
                    onMouseLeave={(e) => e.currentTarget.style.color = '#a78bfa'}>
                    View Credential →
                  </a>
                </div>

                <div style={{
                  background: 'linear-gradient(135deg, rgba(139, 92, 246, 0.1), rgba(59, 130, 246, 0.1))',
                  padding: '1.25rem',
                  borderRadius: '12px',
                  border: '1px solid rgba(139, 92, 246, 0.3)'
                }}>
                  <h3 style={{ fontSize: '1rem', fontWeight: 'bold', margin: '0 0 0.25rem' }}>Microsoft Certified: Azure Fundamentals</h3>
                  <p style={{ color: '#a78bfa', fontSize: '0.875rem', margin: '0 0 0.5rem' }}>Microsoft • 05/2025</p>
                  <p style={{ color: '#94a3b8', fontSize: '0.75rem', fontFamily: 'monospace', marginBottom: '0.5rem' }}>ID: D17775F8F856A4D0</p>
                  <a href="https://learn.microsoft.com/en-us/users/athinimgagule-9151/credentials/d17775f8f856a4d0"
                    target="_blank" rel="noopener noreferrer"
                    style={{ color: '#a78bfa', textDecoration: 'none', fontSize: '0.875rem', fontWeight: '500' }}
                    onMouseEnter={(e) => e.currentTarget.style.color = '#c4b5fd'}
                    onMouseLeave={(e) => e.currentTarget.style.color = '#a78bfa'}>
                    View Credential →
                  </a>
                </div>
              </div>
            </section>
          </div>
        </div>
      </div>

      <style>
        {`
          * {
            box-sizing: border-box;
          }
          body {
            margin: 0;
            background: #0a0e27;
          }
          html {
            scroll-behavior: smooth;
          }
        `}
      </style>
    </div>
  );
};

export default SinglePageCV;