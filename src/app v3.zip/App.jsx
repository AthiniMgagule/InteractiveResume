import React, { useState, useEffect, useRef } from 'react';
import { Mail, Phone, MapPin, Github, Linkedin, Globe, Award, Code, Download, Lightbulb, Star, Target, Rocket, BookOpen, Menu, X, ExternalLink, AlertCircle } from 'lucide-react';

const Badge = ({ children, variant = 'primary' }) => {
  const variants = {
    primary: { bg: 'rgba(0, 255, 200, 0.15)', color: '#00ffc8', border: 'rgba(0, 255, 200, 0.3)' },
    secondary: { bg: 'rgba(255, 20, 147, 0.15)', color: '#ff1493', border: 'rgba(255, 20, 147, 0.3)' },
    accent: { bg: 'rgba(255, 165, 0, 0.15)', color: '#ffa500', border: 'rgba(255, 165, 0, 0.3)' }
  };
  
  const v = variants[variant];
  return (
    <span style={{
      background: v.bg,
      color: v.color,
      padding: '0.35rem 0.8rem',
      borderRadius: 18,
      fontSize: '0.875rem',
      border: `1px solid ${v.border}`,
      display: 'inline-block'
    }}>{children}</span>
  );
};

const EnhancedProjectCard = ({
  title,
  period,
  hero,
  badges = ['Full-stack'],
  codeUrl,
  demoUrl,
  websiteUrl,
  videoDemo,
  status = 'completed',
  caseStudy = {}
}) => {
  const [open, setOpen] = useState(false);
  const [imageLoaded, setImageLoaded] = useState(false);

  const {
    problem = '',
    solution = '',
    role = '',
    outcome = '',
    lessons = '',
    challenge = '',
    architectureDecisions = [],
    edgeCases = [],
    metrics = [],
    tech = [],
    impact = [],
    deployment = ''
  } = caseStudy;

  const liveDemoLink = websiteUrl || demoUrl || videoDemo;
  const statusColors = {
    completed: '#00ffc8',
    ongoing: '#ffa500',
    archived: '#ff1493'
  };

  return (
    <div style={{
      background: 'linear-gradient(135deg, rgba(0, 255, 200, 0.04), rgba(255, 20, 147, 0.04))',
      borderRadius: 16,
      padding: 20,
      border: '1px solid rgba(0, 255, 200, 0.15)',
      display: 'grid',
      gridTemplateColumns: '1fr',
      gap: 16,
      transition: 'all 0.3s ease'
    }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'start', gap: 12, flexWrap: 'wrap' }}>
        <div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 6 }}>
            <h3 style={{ margin: 0, fontSize: 20, color: '#00ffc8' }}>{title}</h3>
            <span style={{
              width: 8,
              height: 8,
              borderRadius: '50%',
              background: statusColors[status],
              boxShadow: `0 0 12px ${statusColors[status]}`,
              animation: status === 'ongoing' ? 'pulse 2s infinite' : 'none'
            }} />
          </div>
          <div style={{ display: 'flex', gap: 8, alignItems: 'center', marginTop: 6, flexWrap: 'wrap' }}>
            <Badge variant="secondary">{period}</Badge>
            {badges.map((badge, idx) => <Badge key={idx} variant="primary">{badge}</Badge>)}
          </div>
        </div>

        <div style={{ display: 'flex', gap: 8, alignItems: 'center', flexWrap: 'wrap' }}>
          {codeUrl && (
            <a href={codeUrl} target="_blank" rel="noopener noreferrer"
              style={{
                display: 'inline-flex', alignItems: 'center', gap: 8,
                padding: '8px 12px', borderRadius: 8, textDecoration: 'none',
                border: '1px solid rgba(0, 255, 200, 0.3)', background: 'transparent', color: '#00ffc8',
                fontWeight: 600, fontSize: 14, transition: 'all 0.2s'
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.borderColor = '#00ffc8';
                e.currentTarget.style.boxShadow = '0 0 12px rgba(0, 255, 200, 0.4)';
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.borderColor = 'rgba(0, 255, 200, 0.3)';
                e.currentTarget.style.boxShadow = 'none';
              }}>
              <Code size={16} />
              View Code
            </a>
          )}

          {liveDemoLink && (
            <a href={liveDemoLink} target="_blank" rel="noopener noreferrer"
              style={{
                display: 'inline-flex', alignItems: 'center', gap: 8,
                padding: '8px 12px', borderRadius: 8, textDecoration: 'none',
                border: '1px solid rgba(255, 20, 147, 0.3)', background: 'transparent', color: '#ff1493',
                fontWeight: 600, fontSize: 14, transition: 'all 0.2s'
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.borderColor = '#ff1493';
                e.currentTarget.style.boxShadow = '0 0 12px rgba(255, 20, 147, 0.4)';
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.borderColor = 'rgba(255, 20, 147, 0.3)';
                e.currentTarget.style.boxShadow = 'none';
              }}>
              <ExternalLink size={16} />
              {videoDemo ? 'Watch Demo' : 'Live Demo'}
            </a>
          )}

          <button onClick={() => setOpen(true)} style={{
            display: 'inline-flex', alignItems: 'center', gap: 8, padding: '8px 12px',
            borderRadius: 8, border: '1px solid rgba(255, 165, 0, 0.3)', background: 'transparent',
            color: '#ffa500', fontWeight: 700, cursor: 'pointer', fontSize: 14, transition: 'all 0.2s'
          }}
          onMouseEnter={(e) => {
            e.currentTarget.style.borderColor = '#ffa500';
            e.currentTarget.style.boxShadow = '0 0 12px rgba(255, 165, 0, 0.4)';
          }}
          onMouseLeave={(e) => {
            e.currentTarget.style.borderColor = 'rgba(255, 165, 0, 0.3)';
            e.currentTarget.style.boxShadow = 'none';
          }}>
            <BookOpen size={16} />
            Case Study
          </button>
        </div>
      </div>

      <div style={{ display: 'flex', gap: 16, alignItems: 'stretch', flexWrap: 'wrap' }}>
        <div style={{
          flex: '0 0 360px',
          minHeight: 200,
          borderRadius: 12,
          overflow: 'hidden',
          boxShadow: '0 10px 30px rgba(0, 255, 200, 0.15)',
          border: '1px solid rgba(0, 255, 200, 0.1)',
          cursor: 'pointer',
          background: '#1a1a2e',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center'
        }}
        onClick={() => setOpen(true)}>
          {hero ? (
            <img 
              src={hero} 
              alt={`${title} preview`} 
              style={{ 
                width: '100%', 
                height: '100%', 
                display: 'block', 
                objectFit: 'cover',
                opacity: imageLoaded ? 1 : 0,
                transition: 'opacity 0.3s ease'
              }}
              onLoad={() => setImageLoaded(true)}
              onError={(e) => e.target.style.display = 'none'}
            />
          ) : (
            <div style={{ color: '#555', textAlign: 'center', padding: '2rem' }}>
              <Code size={48} style={{ marginBottom: '1rem' }} />
              <p>No preview available</p>
            </div>
          )}
        </div>

        <div style={{ flex: '1 1 320px', minWidth: 260 }}>
          <p style={{ color: '#e0e0e0', lineHeight: 1.6, marginBottom: '1rem' }}>
            <strong style={{ color: '#00ffc8' }}>Problem:</strong> {problem}
          </p>
          <p style={{ color: '#e0e0e0', lineHeight: 1.6 }}>
            <strong style={{ color: '#ff1493' }}>Solution:</strong> {solution}
          </p>

          {tech.length > 0 && (
            <div style={{ marginTop: 12 }}>
              <h4 style={{ margin: '8px 0', color: '#00ffc8', fontSize: '0.9rem' }}>Tech Stack</h4>
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6 }}>
                {tech.map((item, i) => (
                  <span key={i} style={{
                    background: 'rgba(0, 255, 200, 0.12)',
                    color: '#00ffc8',
                    padding: '0.25rem 0.75rem',
                    borderRadius: 12,
                    fontSize: '0.8rem',
                    border: '1px solid rgba(0, 255, 200, 0.2)'
                  }}>
                    {typeof item === 'string' ? item : item.name}
                  </span>
                ))}
              </div>
            </div>
          )}

          {metrics.length > 0 && (
            <div style={{ marginTop: 12, display: 'flex', gap: 6, flexWrap: 'wrap' }}>
              {metrics.map((m, idx) => (
                <span key={idx} style={{
                  background: 'rgba(255, 165, 0, 0.12)',
                  color: '#ffa500',
                  padding: '0.25rem 0.75rem',
                  borderRadius: 12,
                  fontSize: '0.75rem',
                  border: '1px solid rgba(255, 165, 0, 0.2)'
                }}>
                  {m}
                </span>
              ))}
            </div>
          )}
        </div>
      </div>

      {open && (
        <div style={{
          position: 'fixed', inset: 0, zIndex: 3000, display: 'flex', alignItems: 'center', justifyContent: 'center',
          background: 'rgba(0, 0, 0, 0.85)', padding: 24, backdropFilter: 'blur(4px)'
        }}
        onClick={() => setOpen(false)}>
          <div style={{ 
            width: 'min(900px, 96%)', 
            background: '#0f0f1e', 
            borderRadius: 12, 
            padding: 24, 
            border: '1px solid rgba(0, 255, 200, 0.2)',
            maxHeight: '90vh',
            overflowY: 'auto'
          }}
          onClick={(e) => e.stopPropagation()}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'start', marginBottom: 20 }}>
              <h3 style={{ margin: 0, color: '#00ffc8', fontSize: '1.5rem' }}>{title} — Case Study</h3>
              <button onClick={() => setOpen(false)} 
                style={{ background: 'transparent', border: 'none', color: '#00ffc8', cursor: 'pointer', fontSize: 24, padding: 0 }}>
                ✕
              </button>
            </div>

            <div style={{ color: '#e0e0e0', lineHeight: 1.8 }}>
              {problem && (
                <>
                  <h4 style={{ color: '#00ffc8', marginTop: '1.5rem' }}>The Problem</h4>
                  <p>{problem}</p>
                </>
              )}

              {solution && (
                <>
                  <h4 style={{ color: '#ff1493', marginTop: '1.5rem' }}>The Solution</h4>
                  <p>{solution}</p>
                </>
              )}

              {role && (
                <>
                  <h4 style={{ color: '#00ffc8', marginTop: '1.5rem' }}>My Role</h4>
                  <p>{role}</p>
                </>
              )}

              {architectureDecisions.length > 0 && (
                <>
                  <h4 style={{ color: '#ffa500', marginTop: '1.5rem' }}>Architecture Decisions</h4>
                  <ul style={{ paddingLeft: 20 }}>
                    {architectureDecisions.map((d, i) => (
                      <li key={i} style={{ marginBottom: '0.5rem' }}>{d}</li>
                    ))}
                  </ul>
                </>
              )}

              {edgeCases.length > 0 && (
                <>
                  <h4 style={{ color: '#ffa500', marginTop: '1.5rem' }}>Edge Cases & Solutions</h4>
                  <ul style={{ paddingLeft: 20 }}>
                    {edgeCases.map((e, i) => (
                      <li key={i} style={{ marginBottom: '0.5rem' }}>{e}</li>
                    ))}
                  </ul>
                </>
              )}

              {challenge && (
                <>
                  <h4 style={{ color: '#ff1493', marginTop: '1.5rem' }}>Technical Challenge</h4>
                  <p>{challenge}</p>
                </>
              )}

              {outcome && (
                <>
                  <h4 style={{ color: '#00ffc8', marginTop: '1.5rem' }}>Outcome</h4>
                  <p>{outcome}</p>
                </>
              )}

              {lessons && (
                <>
                  <h4 style={{ color: '#00ffc8', marginTop: '1.5rem' }}>What I Learned</h4>
                  <p>{lessons}</p>
                </>
              )}

              {deployment && (
                <>
                  <h4 style={{ color: '#ffa500', marginTop: '1.5rem' }}>Deployment</h4>
                  <p>{deployment}</p>
                </>
              )}

              {metrics.length > 0 && (
                <>
                  <h4 style={{ color: '#00ffc8', marginTop: '1.5rem' }}>Key Metrics</h4>
                  <ul style={{ paddingLeft: 20 }}>
                    {metrics.map((m, i) => <li key={i} style={{ marginBottom: '0.5rem' }}>{m}</li>)}
                  </ul>
                </>
              )}

              {tech.length > 0 && (
                <>
                  <h4 style={{ color: '#00ffc8', marginTop: '1.5rem' }}>Technology Stack</h4>
                  <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8, marginTop: 8 }}>
                    {tech.map((item, i) => (
                      <Badge key={i} variant="primary">{typeof item === 'string' ? item : item.name}</Badge>
                    ))}
                  </div>
                </>
              )}

              <div style={{ marginTop: '2rem', paddingTop: '1rem', borderTop: '1px solid rgba(0, 255, 200, 0.2)' }}>
                {codeUrl && (
                  <a href={codeUrl} target="_blank" rel="noopener noreferrer"
                    style={{ color: '#00ffc8', display: 'inline-block', marginRight: '1.5rem', textDecoration: 'none', fontWeight: 600 }}>
                    💻 View Source Code →
                  </a>
                )}
                {liveDemoLink && (
                  <a href={liveDemoLink} target="_blank" rel="noopener noreferrer"
                    style={{ color: '#ff1493', display: 'inline-block', textDecoration: 'none', fontWeight: 600 }}>
                    🚀 {videoDemo ? 'Watch Demo' : 'Try Live Demo'} →
                  </a>
                )}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

const EnhancedPortfolio = () => {
  const [scrollY, setScrollY] = useState(0);
  const [activeChapter, setActiveChapter] = useState(0);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const sectionsRef = useRef([]);

  const handleDownloadCV = () => {
    const link = document.createElement('a');
    link.href = 'https://drive.google.com/uc?export=download&id=1iJ4zLlb196IW63VwQ9_FlB2zFcoOnIfH';
    link.download = 'Athini_Mgagule_Resume.pdf';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  useEffect(() => {
    const handleScroll = () => {
      setScrollY(window.scrollY);
      
      const scrollPosition = window.scrollY + window.innerHeight / 3;
      sectionsRef.current.forEach((section, index) => {
        if (section && section.offsetTop <= scrollPosition) {
          setActiveChapter(index);
        }
      });
    };
    
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const chapters = [
    { id: 'intro', label: 'The Beginning', icon: Lightbulb },
    { id: 'journey', label: 'The Journey', icon: Star },
    { id: 'skills', label: 'Skills & Tools', icon: Target },
    { id: 'work', label: 'The Work', icon: Code },
    { id: 'future', label: 'Next Chapter', icon: Rocket }
  ];

  const scrollToSection = (index) => {
    if (sectionsRef.current[index]) {
      sectionsRef.current[index].scrollIntoView({ behavior: 'smooth', block: 'start' });
      setMobileMenuOpen(false);
    }
  };

  const projects = [
    {
      title: 'ApplyConnect',
      period: 'Ongoing',
      hero: '/images/ApplyConnect.png',
      badges: ['Full-stack', 'React', 'Node.js', 'PWA'],
      codeUrl: '',
      videoDemo: '',
      caseStudy: {
        problem: 'Students in South Africa and across the continent face a fragmented bursary application landscape. Opportunities are scattered across hundreds of websites (university portals, corporate sites, government pages), many with inconsistent formats. Students in areas with unreliable internet (40% of SA has intermittent connectivity) struggle to complete applications when connections drop mid-session, leading to lost progress and missed deadlines.',
        solution: 'Built ApplyConnect, a Progressive Web App that aggregates bursary opportunities through intelligent web scraping, provides offline-first application saving with automatic sync, and supports multilingual interfaces (English, isiZulu, Afrikaans, Sesotho) to reduce language barriers. The React frontend uses IndexedDB for offline storage and service workers for background sync, while the Node.js backend handles scraping with Puppeteer and stores structured data in MongoDB.',
        role: 'Solo full-stack developer. Architected the entire system from database schema to UI/UX. Built web scraping pipelines with retry logic and rate limiting, designed offline-first architecture with conflict resolution strategies, implemented i18n with context-aware translations, and created responsive UI optimized for both desktop and mobile (targeting students on feature phones with limited data).',
        challenge: 'Web scraping proved brittle—websites change layouts frequently, breaking selectors. Implemented a hybrid approach: CSS selectors with fallback XPath queries, plus a notification system that alerts me when scrapers fail (monitored via Cron jobs). Also struggled with offline-sync conflicts: what happens when a user edits an application offline while the server has newer data? Solved with last-write-wins plus versioning metadata, showing users a diff when conflicts occur.',
        architectureDecisions: [
          'PWA over native app: Single codebase for Android/iOS/Web. Service workers enable offline functionality without app store barriers. Students can access via browser, reducing 200MB+ download requirement.',
          'IndexedDB over localStorage: Supports structured data and transactions. Can store entire application forms (20KB+) vs localStorage 5MB limit. Async API prevents UI blocking during large writes.',
          'Puppeteer over Cheerio: Some bursary sites use JavaScript rendering (React SPAs). Cheerio only parses static HTML. Puppeteer runs headless Chrome, handling dynamic content, but increases scraping time 3x (trade-off for accuracy).',
          'i18next for i18n: Supports nested translations, pluralization rules per language, and lazy-loading of translation files (reduces initial bundle by 40%). Context-aware: "Apply" (verb) vs "Apply" (application form) translated differently.'
        ],
        edgeCases: [
          'Stale scraper data: When websites block requests or change structure, show users last-known-good data with staleness warning. Manual fallback form lets users submit URL for manual review.',
          'Partial offline saves: If device runs out of storage mid-save, rollback transaction and prompt user to free space. Prevents corrupted application states.',
          'Language switching mid-form: Preserve form data when user switches languages. Map field IDs (not labels) to maintain state across translations.',
          'Duplicate applications: Hash form data + bursary ID to detect if user already applied. Show warning: "You submitted a similar application on [date]" to prevent accidental duplicates.',
          'Timezone handling: Application deadlines stored in UTC, displayed in user local time. South Africa (SAST) is UTC+2, critical for same-day deadlines.',
          'Network flapping: When connection is unstable (intermittent drops), debounce sync attempts. Wait for 10s stable connection before syncing to avoid partial uploads.'
        ],
        lessons: 'Building for offline-first fundamentally changes application architecture—you cannot rely on server as source of truth. Every action must be queueable and idempotent. Learned that web scraping is 20% code, 80% maintenance; websites break constantly, requiring defensive programming. Also discovered the importance of accessibility: what seems like a "simple" web app becomes complex when supporting users with limited data (optimize bundle size), low-end devices (minimize JS execution), and multiple languages (text expansion/contraction breaks layouts). Most importantly: talk to users early. Initial design assumed students wanted auto-fill; they actually wanted a central dashboard to track deadlines across opportunities.',
        tech: ['React 18','Node.js','Express','MySQL','Puppeteer','IndexedDB','Service Workers','Workbox','i18next','PWA']
      }
    },
    {
      title: 'Car Rental Management System',
      period: 'Ongoing',
      hero: '/images/CarRental.png',
      badges: ['Full-stack', 'React', 'Node.js', 'Android'],
      codeUrl: 'https://github.com/AthiniMgagule/FYP_2025',
      videoDemo: '',
      caseStudy: {
        problem: 'Traditional car rental businesses rely on manual processes—phone bookings, paper contracts, spreadsheet fleet tracking—leading to double-bookings, poor vehicle utilization (60% average in small agencies), and customer frustration with opaque pricing. Customers lack real-time availability insights, and staff spend 30+ minutes per booking on administrative tasks. Small-to-medium rental agencies need affordable digital solutions but can\'t justify enterprise systems costing R50K+.',
        solution: 'Built a full-stack car rental platform with dual interfaces: Android app for customers (booking, payment, history) and React web portal for admins (fleet management, availability calendar, analytics). Node.js backend provides REST APIs with role-based access control, real-time inventory management using database transactions to prevent race conditions, and automated pricing with dynamic surge logic during peak periods.',
        role: 'Backend architect and admin portal developer in a 2-person team. Designed and implemented the entire Node.js/Express backend including authentication (JWT), booking state machine (reserved → confirmed → active → completed), payment integration, and vehicle inventory system with conflict resolution. Built React admin dashboard with real-time updates, fleet analytics, and booking management. Partner focused on Android customer app using Java in Android Studio, consuming APIs I built.',
        challenge: 'Preventing race conditions was critical: what happens when two customers try to book the last available vehicle simultaneously? Initial approach used application-level locks (naive), which failed under concurrent requests. Solved with database transactions with SELECT FOR UPDATE, ensuring atomic read-modify-write operations. Also struggled with payment integration—third-party APIs have unpredictable latencies (200ms-3s). Implemented webhook listeners for async payment confirmation rather than blocking booking flow, improving UX significantly.',
        architectureDecisions: [
          'Microservice backend over monolithic.',
          'JWT over session cookies: Android app requires token-based auth (no cookie support). JWTs enable stateless authentication, reducing server memory. Tokens expire after 7 days with refresh token rotation.',
          'REST over GraphQL: Simpler for team with limited GraphQL experience. REST endpoints map cleanly to CRUD operations. Reduced learning curve allowed faster development.',
          'React SPA for admin vs server-rendered: Admins need real-time updates (new bookings, cancellations). WebSocket integration simpler with SPA. Tradeoff: slower initial load (acceptable for internal tool).',
          'Android native vs React Native: Partner had Java experience. Native Android provides better performance for maps integration (showing nearby pickup locations) and offline mode for viewing booking history.'
        ],
        
        edgeCases: [
          'Booking conflicts: Database unique constraint on (vehicle_id, date_range) prevents overlapping bookings. If conflict detected, API returns 409 Conflict with list of alternative vehicles/dates.',
          'Payment failures: If payment succeeds but booking creation fails (network issue), webhook handler retries with idempotency keys. Customer not charged twice. Manual reconciliation dashboard for edge cases.',
          'Vehicle maintenance mode: Admin can mark vehicle unavailable (maintenance, damage). System auto-cancels future bookings with refunds and notifies affected customers via email/push notifications.',
          'Late returns: Cron job runs hourly, detecting overdue returns. Automatically charges late fees (10% per hour) to customer\'s payment method. Admin receives alert to contact customer.',
          'Partial data sync: Android app caches booking history offline. When online, syncs with backend. Conflict resolution: server always wins for active bookings, local cache for completed bookings.'
        ], 
        lessons: 'Learned that state management is the hardest part of booking systems—tracking transitions between reserved/confirmed/active/completed/cancelled requires careful state machine design. One missing edge case (e.g., payment refund during cancellation) creates support nightmares. Also discovered the importance of API versioning early: when we changed the booking response format, it broke the Android app for existing users. Now use /api/v1/ prefix with backward compatibility. Most valuable lesson: over-communicate with team partner—we wasted 3 days building overlapping features because we didn\'t clarify API contracts upfront. Swagger documentation became essential.',
        tech: [
          'React 18',
          'Node.js',
          'Express',
          'MySQL',
          'JWT',
          'WebSockets',
          'Java',
          'Android Studio',
          'REST API',
          'Cron Jobs'
        ]
      }
    },
    {
      title: 'Bank Management System',
      period: 'Ongoing',
      hero: '',
      badges: ['Desktop App', 'Java', 'Serialization'],
      codeUrl: '',
      videoDemo: '',
      caseStudy: {
        problem: 'Community banks and credit unions in rural areas lack affordable core banking software. Enterprise solutions (Temenos, FIS) cost R100K+ annually, pricing out small institutions serving <5,000 customers. Tellers rely on manual ledgers or Excel spreadsheets, leading to human error (5-8% transaction mistakes), no audit trails, and regulatory compliance risks. Customers wait 15-20 minutes for simple transactions due to manual reconciliation.',
        solution: 'Building a desktop banking application in Java with MySQL backend, providing essential banking operations: account management (savings, checking), deposits/withdrawals, inter-account transfers, transaction history, and basic reporting. JavaFX GUI optimized for teller workflows with keyboard shortcuts for rapid transaction processing. Offline-first architecture allows branch operations during internet outages, syncing with central database when connectivity restored.',
        role: 'Solo developer building MVP for a internship project. Designing database schema with double-entry bookkeeping principles (every transaction creates balanced debit/credit entries). Implementing transaction atomicity using MySQL transactions to ensure data consistency. Creating role-based access system (teller, manager, admin) with audit logging for regulatory compliance. Building JavaFX interfaces optimized for speed and minimal training required.',
        challenge: 'Ensuring transaction integrity is paramount—banking software cannot lose or duplicate money. Implementing ACID properties at application level: wrapping every financial operation in MySQL transactions with rollback on failure. Struggled with concurrency: if two tellers process transactions on same account simultaneously, must maintain correct balance. Solved with optimistic locking—each transaction includes expected balance; if mismatch, transaction fails and user retries. Also learning regulatory requirements (KYC, AML) and building compliance features (flagging large transactions, ID verification).',
        architectureDecisions: [
          'Desktop app over web: Rural branches have unreliable internet (4-6 hour daily outages). Desktop app with local MySQL instance ensures operations continue offline. Sync engine pushes transactions to central server when online.',
          'Java Swing/JavaFX over Electron: Lower memory footprint (150MB vs 500MB+). Teller workstations often run Windows 7 with 4GB RAM. Native Java performance critical for sub-second transaction processing.',
          'MySQL over SQLite: Needs multi-user concurrent access (5-10 tellers per branch). MySQL supports row-level locking and transactions better than SQLite. Also, easier migration path to centralized server later.',
          'Double-entry bookkeeping: Every transaction creates two entries (debit one account, credit another). Ensures books always balance. Sum of all debits must equal sum of all credits—enables automated reconciliation.',
          'Stored procedures for transactions: Critical banking logic (transfer, withdraw) implemented as MySQL stored procedures. Reduces application-database round trips and ensures business rules enforced at database level.',
          'Offline queue with conflict resolution: Transactions created offline stored in local queue. On sync, server checks for conflicts (e.g., insufficient balance at central server). Conflicts flagged for manager review.'
        ],
        
        edgeCases: [
          'Insufficient funds: Before withdrawal/transfer, check available balance minus holds (pending transactions). Prevent overdrafts with grace amount (configurable, e.g., -$50).',
          'Concurrent transactions: Use optimistic locking with version numbers. If two tellers modify same account, second transaction fails with "Balance changed, please retry" message.',
          'Transaction reversal: If error detected (wrong amount entered), teller can reverse transaction within 1 hour. Creates offsetting entries with reference to original transaction. After 1 hour, requires manager approval.',
          'Offline sync conflicts: If account closed at central server but teller processes transaction offline, sync rejects transaction. Refund customer and log incident.',
          'Decimal precision: Use DECIMAL(19,4) for money amounts (not FLOAT/DOUBLE). Floating-point arithmetic causes rounding errors (0.1 + 0.2 ≠ 0.3). Critical for financial accuracy.',
          'Audit immutability: Transaction logs cannot be deleted or modified, even by admins. Creates compliance audit trail. Only soft deletes (status=\'VOID\') with reason code.'
        ],
        
        lessons: 'Learning that banking software is 10% features, 90% error handling and edge cases. Every operation must be reversible, auditable, and compliant. Discovered the importance of domain modeling—initial schema had "transactions" table; realized needed separate entries table (debits/credits) to implement double-entry bookkeeping correctly. Also learning to think like an attacker: if a teller wanted to steal money, how would they exploit the system? This mindset reveals security gaps (e.g., need separation of duties—teller can\'t approve own large transactions). Most valuable lesson: regulatory compliance is not optional "later" work—it must be baked into architecture from day one.',
        tech: [
          'Java 17',
          'JavaFX',
          'MySQL 8.0',
          'JDBC',
          'Stored Procedures',
          'Optimistic Locking',
          'Double-Entry Bookkeeping',
          'Encryption (AES-256)',
          'Audit Logging',
          'VPN',
        ]
      }
    },
    {
      title: 'URL Shortener',
      period: '08/2025 - 09/2025',
      status: 'completed',
      hero: '/images/url_shortener.png',
      badges: ['Full-stack', 'Spring Boot', 'Production'],
      codeUrl: 'https://github.com/AthiniMgagule/URLShortener',
      demoUrl: 'https://url-shortener-demo.example.com',
      caseStudy: {
        problem: 'Users needed a way to share unwieldy long URLs, especially in space-constrained contexts like Twitter (280 char limit) and marketing materials. Existing solutions were either slow (50-100ms per redirect) or lacked reliability guarantees.',
        solution: 'Engineered a production-ready URL shortener using Base62 encoding with collision detection, MySQL with strategic indexing for sub-50ms lookups, and a React frontend supporting batch URL shortening and analytics dashboards.',
        role: 'Solo full-stack architect. Designed the hashing algorithm with retry logic for collision avoidance, built REST API endpoints with Spring Boot, optimized MySQL schema with composite indices on shortened_url and created_at, and developed a responsive React UI with real-time URL management.',
        challenge: 'Initial sequential ID approach was vulnerable to enumeration attacks and predictable. Switched to Base62 encoding (62^6 = 56 billion combinations) with retry logic when collisions occur. This created a trade-off: slightly slower insertion (avg 12ms vs 3ms) but exponentially harder to guess URLs.',
        architectureDecisions: [
          'Base62 encoding over UUID: Shorter URLs (6-8 chars vs 36 chars), human-readable, easily guessable length provides intuitive UX.',
          'MySQL over NoSQL: ACID guarantees essential for collision detection. Indexing on shortened_url enables O(log n) lookups.',
          'Composite index (shortened_url, created_at): Enables fast lookups AND time-range queries for analytics without separate index.',
          'Spring Boot with JPA: Type-safe queries reduce SQL injection surface. Hibernate lazy-loading prevents N+1 queries.'
        ],
        edgeCases: [
          'Collision handling: When hashing collides, retry with salt increment. 99.9% resolved in <3 retries due to large keyspace.',
          'Concurrent requests: Database unique constraint prevents race conditions where two requests create same shortened ID simultaneously.',
          'URL validation: Regex pattern matching + DNS lookup attempt to catch invalid/typo URLs before shortening.',
          'Redirect loops: Shortened URL cannot point to itself or create redirect chains (validates target before storage).'
        ],
        lessons: 'Learned that "simple" problems hide complexity. What seemed like a 1-hour project revealed the importance of collision strategies, indexing patterns, and failure modes. Mastered MySQL performance tuning—a single missing index can degrade performance 40x. Also discovered: users rarely care about feature count; they care about speed and reliability.',
        tech: ['React 18', 'Spring Boot 3.0', 'MySQL 8.0', 'REST API', 'Base62 Encoding', 'JPA/Hibernate', 'Git', 'Render', 'Netlify']
      }
    },
    {
      title: 'WriteWisp',
      period: '07/2025 - Ongoing',
      status: 'ongoing',
      hero: '/images/write_wisp.png',
      badges: ['Full-stack', 'React', 'Active Development'],
      codeUrl: 'https://github.com/AthiniMgagule/WriteWisp',
      videoDemo: '/videos/write_wisp.mp4',
      caseStudy: {
        problem: 'Writers struggle with creative friction: scattered drafts across multiple platforms (Google Docs, Notion, Notes app), no structured prompts to overcome writer\'s block, and poor version history. I wanted to build a distraction-free writing environment that\'s actually enjoyable to use.',
        solution: 'Built a web app using React with autosave (every 5 seconds), prompt suggestions, and version history allowing rollback. Minimalist UI surfaces only essential controls—focus on writing, not features.',
        role: 'Solo full-stack developer. Handled frontend in React with debounced autosave to prevent database thrashing. Integrated OpenAI API with caching to reduce API calls and latency. Built backend with Node/Express, implemented version control with simple immutable history pattern.',
        outcome: 'Created 15+ drafts during personal testing. App is performant, saves reliably, and feels responsive. No external testing yet, but the workflow is solid and the core feature set works as intended.',
        challenge: 'OpenAI API rate limits caused initial UI freezes when requesting prompts rapidly. Solved by implementing 500ms debounce with in-memory caching—groups requests and batches API calls. Also learned to handle API errors gracefully without breaking the writing flow.',
        architectureDecisions: [
          'React + Node.js: Simple, familiar stack I know well. Easy to reason about and maintain.',
          'Debounced API calls + caching: Batch requests instead of hitting API on every interaction. Reduced latency significantly.',
          'Version history as append-only log: Each autosave creates new entry. Simple to implement, trivial to rollback.',
          'React Context for state: No Redux needed. Keeps bundle small and mental model clear.'
        ],
        edgeCases: [
          'Rapid autosaves: Debounce system ensures database isn\'t overwhelmed by frequent writes.',
          'API failures: Graceful fallback—app continues working even if prompt API fails. User can still write.',
          'Network interruption: Currently assumes connection. Could add offline support later if needed.',
          'Losing unsaved work: Autosave every 5s prevents significant data loss.'
        ],
        lessons: 'Learned that performance and UX are tightly coupled. A feature that technically works but feels slow gets abandoned. Also: building for yourself teaches you what actually matters. I initially over-engineered features nobody needed. Cut them, shipped what was essential, and it\'s much better for it.',
        tech: ['React 18', 'Node.js/Express', 'PostgreSQL', 'OpenAI API', 'Git', 'Netlify', 'Render']
      }
    }
  ];

  const skillCategories = [
    {
      title: 'Proficient (1–2 years, solid practical experience)',
      skills: [
        { name: 'Java', detail: 'Spring Boot • Built small projects • Good grasp of dependency injection and ORM basics' },
        { name: 'Python', detail: 'Algorithmic problem solving • Data structures • Used in academic and personal projects' },
        { name: 'SQL / MySQL', detail: 'Writing queries • Basic schema design • Joins and indexing fundamentals' },
        { name: 'JavaScript', detail: 'ES6+ syntax, async/await, DOM manipulation, and debugging' }
      ]
    },
    {
      title: 'Competent (hands-on project experience)',
      skills: [
        { name: 'React', detail: 'Hooks, components, and state management • Built a few feature-rich web apps' },
        { name: 'Node.js / Express', detail: 'REST APIs, middleware, and simple authentication patterns' },
        { name: 'HTML & CSS', detail: 'Responsive layouts, flexbox/grid, and accessibility best practices' },
        { name: 'Git', detail: 'Version control, branching, and collaborative workflows' }
      ]
    },
    {
      title: 'Developing (actively learning and improving)',
      skills: [
        { name: 'PostgreSQL', detail: 'Query writing, schema design, and basic optimization • Started 09/2025' },
        { name: 'Azure Cloud', detail: 'Deployment basics, infrastructure fundamentals (Faith Mangope program)' },
        { name: 'Power BI', detail: 'Data visualization, dashboard creation (recently acquired certification)' },
        { name: 'Spring Boot', detail: 'Building REST APIs, dependency injection, and microservice patterns (current focus)' },
        { name: 'AI', detail: 'Used StarCoder2 & Mistral via NVIDIA • Automated test generation via Node.js & React'}
      ]
    }
  ];


  return (
    <div style={{
      minHeight: '100vh',
      background: 'linear-gradient(180deg, #0f0f1e 0%, #1a1a2e 50%, #0f0f1e 100%)',
      color: '#e0e0e0',
      fontFamily: 'system-ui, -apple-system, sans-serif',
      position: 'relative'
    }}>
      {/* Desktop Navigation dots */}
        <div style={{
        position: 'fixed',
        right: '2rem',
        top: '50%',
        transform: 'translateY(-50%)',
        zIndex: 1000,
        display: window.innerWidth > 768 ? 'flex' : 'none',
        flexDirection: 'column',
        gap: '1rem'
      }}>
        {chapters.map((chapter, index) => (
          <div
            key={chapter.id}
            onClick={() => scrollToSection(index)}
            style={{
              cursor: 'pointer',
              display: 'flex',
              alignItems: 'center',
              gap: '0.75rem',
              transition: 'all 0.3s ease'
            }}>
              <span style={{
                fontSize: '0.75rem',
                color: activeChapter === index ? '#00ffc8' : '#555',
                opacity: activeChapter === index ? 1 : 0,
                transform: activeChapter === index ? 'translateX(0)' : 'translateX(10px)',
                transition: 'all 0.3s ease',
                whiteSpace: 'nowrap'
              }}>
                {chapter.label}
              </span>
              <div style={{
                width: activeChapter === index ? '12px' : '8px',
                height: activeChapter === index ? '12px' : '8px',
                borderRadius: '50%',
                background: activeChapter === index ? '#00ffc8' : '#333',
                border: `2px solid ${activeChapter === index ? '#00ffc8' : '#444'}`,
                transition: 'all 0.3s ease',
                boxShadow: activeChapter === index ? '0 0 20px rgba(0, 255, 200, 0.6)' : 'none'
              }} />
            </div>
          ))}
        </div>

        {/* Mobile Navigation */}
        {window.innerWidth <= 768 && (
          <>
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              style={{
                position: 'fixed',
                bottom: '2rem',
                right: '2rem',
                zIndex: 2000,
                width: '56px',
                height: '56px',
                borderRadius: '50%',
                background: 'linear-gradient(135deg, #00ffc8, #ff1493)',
                border: 'none',
                color: '#0f0f1e',
                cursor: 'pointer',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                boxShadow: '0 10px 30px rgba(0, 255, 200, 0.4)'
              }}
            >
              {mobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>

            {mobileMenuOpen && (
              <div style={{
                position: 'fixed',
                bottom: '5rem',
                right: '2rem',
                zIndex: 1999,
                background: 'rgba(15, 15, 30, 0.98)',
                backdropFilter: 'blur(10px)',
                borderRadius: '12px',
                padding: '1rem',
                border: '1px solid rgba(0, 255, 200, 0.3)',
                boxShadow: '0 10px 40px rgba(0, 0, 0, 0.5)'
              }}>
                {chapters.map((chapter, index) => (
                  <button
                    key={chapter.id}
                    onClick={() => scrollToSection(index)}
                    style={{
                      display: 'block',
                      width: '100%',
                      padding: '0.75rem 1rem',
                      marginBottom: '0.5rem',
                      background: activeChapter === index ? 'rgba(0, 255, 200, 0.2)' : 'transparent',
                      border: 'none',
                      borderRadius: '8px',
                      color: activeChapter === index ? '#00ffc8' : '#e0e0e0',
                      textAlign: 'left',
                      cursor: 'pointer',
                      fontSize: '0.875rem',
                      fontWeight: activeChapter === index ? '600' : '400',
                      transition: 'all 0.2s ease'
                    }}
                  >
                    {chapter.label}
                  </button>
                ))}
              </div>
            )}
          </>
        )}

        {/* Fixed header */}
        <div style={{
          position: 'fixed',
          top: 0,
          left: 0,
          right: 0,
          background: `rgba(15, 15, 30, ${Math.min(scrollY / 200, 0.95)})`,
          backdropFilter: 'blur(10px)',
          borderBottom: '1px solid rgba(0, 255, 200, 0.15)',
          padding: '1rem 2rem',
          zIndex: 999,
          transition: 'all 0.3s ease'
        }}>
          <div style={{ maxWidth: '1200px', margin: '0 auto', display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '1rem' }}>
            <div>
              <h1 style={{ margin: 0, fontSize: '1.5rem', fontWeight: 'bold', background: 'linear-gradient(135deg, #00ffc8, #ff1493)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent' }}>
                Athini Mgagule
              </h1>
              <p style={{ margin: 0, fontSize: '0.875rem', color: '#888' }}>Software Developer</p>
            </div>
            <a href="https://drive.google.com/file/d/1iJ4zLlb196IW63VwQ9_FlB2zFcoOnIfH/view?usp=drive_link" target="_blank" rel="noopener noreferrer"
              style={{
                background: 'linear-gradient(135deg, #00ffc8, #ff1493)',
                border: 'none',
                borderRadius: '8px',
                color: '#0f0f1e',
                cursor: 'pointer',
                padding: '0.5rem 1.5rem',
                display: 'flex',
                alignItems: 'center',
                gap: '0.5rem',
                fontSize: '0.875rem',
                fontWeight: '600',
                transition: 'all 0.3s ease',
                textDecoration: 'none'
              }}
              onClick={(e) => {
                e.preventDefault();
                handleDownloadCV();
              }}
              onMouseEnter={(e) => e.currentTarget.style.transform = 'scale(1.05)'}
              onMouseLeave={(e) => e.currentTarget.style.transform = 'scale(1)'}
            >
              <Download size={16} />
              Download CV
            </a>
          </div>
        </div>

        {/* Main content */}
        <div style={{ maxWidth: '1200px', margin: '0 auto', padding: '6rem 2rem 3rem' }}>
          
          {/* Chapter 1: The Beginning */}
          <section ref={el => sectionsRef.current[0] = el} style={{ minHeight: '100vh', display: 'flex', flexDirection: 'column', justifyContent: 'center', marginBottom: '6rem' }}>
            <div style={{ textAlign: 'center', maxWidth: '800px', margin: '0 auto' }}>
              <div style={{
                width: '350px',
                height: '350px',
                margin: '0 auto 2rem',
                borderRadius: '10%',
                overflow: 'hidden',
                boxShadow: '0 0 60px rgba(0, 255, 200, 0.4)',
                animation: 'float 3s ease-in-out infinite',
                border: '4px solid transparent',
                backgroundImage: 'linear-gradient(#0f0f1e, #0f0f1e), linear-gradient(135deg, #00ffc8, #ff1493)',
                backgroundOrigin: 'border-box',
                backgroundClip: 'padding-box, border-box',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center'
              }}> 
              {/* i need the part with the picture to have the typical see projects button */}
                <div style={{ color: '#555', fontSize: '4rem' }}>
                  <img src="/images/AthiniMgagulePP.jpg" alt=""></img>
                </div>
              </div>
              
              <h2 style={{ 
                fontSize: '3rem', 
                fontWeight: 'bold', 
                marginBottom: '2rem',
                background: 'linear-gradient(135deg, #00ffc8, #ff1493)',
                WebkitBackgroundClip: 'text',
                WebkitTextFillColor: 'transparent',
                lineHeight: '1.2'
              }}>
                Hi, I'm Athini
              </h2>
              
              <div style={{ 
                color: '#e0e0e0', 
                fontSize: '1.125rem', 
                lineHeight: '1.8',
                textAlign: 'left',
                background: 'linear-gradient(135deg, rgba(0, 255, 200, 0.08), rgba(255, 20, 147, 0.08))',
                padding: '2rem',
                borderRadius: '16px',
                border: '1px solid rgba(0, 255, 200, 0.2)',
                marginBottom: '2rem'
              }}>
                <p style={{ marginBottom: '1.5rem' }}>
                  I'm a <strong style={{ color: '#00ffc8' }}>Software Developer</strong> who solves hard problems with elegant code. I specialize in full-stack applications, optimizing data systems, and building reliable software that users actually enjoy using.
                </p>
                <p style={{ margin: 0 }}>
                  With a <strong style={{ color: '#ff1493' }}>BSc in Computer Science and Mathematics</strong> from Wits, I bring analytical rigor to every project. I don't just ship features—I understand trade-offs, measure impact, and iterate based on real constraints. Whether it's reducing database latency by 40%, architecting APIs, or solving cache invalidation problems, I approach each challenge with the same principle: <strong style={{ color: '#00ffc8' }}>understand the problem deeply before coding.</strong>
                </p>
              </div>  
            </div>
          </section>

          {/* Chapter 2: The Journey */}
          <section ref={el => sectionsRef.current[1] = el} style={{ marginBottom: '6rem' }}>
            <h2 style={{ 
              fontSize: '2.5rem', 
              fontWeight: 'bold', 
              marginBottom: '3rem',
              textAlign: 'center',
              background: 'linear-gradient(135deg, #00ffc8, #ff1493)',
              WebkitBackgroundClip: 'text',
              WebkitTextFillColor: 'transparent'
            }}>
              Learning to Build
            </h2>

            <div style={{ maxWidth: '900px', margin: '0 auto 3rem' }}>
              <div style={{ position: 'relative', paddingLeft: '3rem' }}>
                <div style={{
                  position: 'absolute',
                  left: '1rem',
                  top: 0,
                  bottom: 0,
                  width: '2px',
                  background: 'linear-gradient(180deg, #00ffc8, #ff1493)',
                  opacity: 0.4
                }} />

                {/* Faith Mangope */}
                <div style={{ marginBottom: '2rem', position: 'relative' }}>
                  <div style={{
                    position: 'absolute',
                    left: '-2.25rem',
                    top: '0.5rem',
                    width: '16px',
                    height: '16px',
                    borderRadius: '50%',
                    background: '#00ffc8',
                    border: '3px solid #0f0f1e',
                    boxShadow: '0 0 20px rgba(0, 255, 200, 0.6)'
                  }} />
                  <div
                    style={{
                      background: 'linear-gradient(135deg, rgba(0, 255, 200, 0.08), rgba(255, 20, 147, 0.05))',
                      padding: '1.5rem',
                      borderRadius: '12px',
                      border: '1px solid rgba(0, 255, 200, 0.2)',
                      cursor: 'pointer',
                      transition: 'all 0.3s ease',
                      overflow: 'hidden'
                    }}
                    onMouseEnter={(e) => {
                      e.currentTarget.style.borderColor = 'rgba(0, 255, 200, 0.5)';
                      e.currentTarget.style.transform = 'scale(1.02)';
                      const details = e.currentTarget.querySelector('.details');
                      if (details) {
                        details.style.maxHeight = '500px';
                        details.style.opacity = '1';
                      }
                    }}
                    onMouseLeave={(e) => {
                      e.currentTarget.style.borderColor = 'rgba(0, 255, 200, 0.2)';
                      e.currentTarget.style.transform = 'scale(1)';
                      const details = e.currentTarget.querySelector('.details');
                      if (details) {
                        details.style.maxHeight = '0';
                        details.style.opacity = '0';
                      }
                    }}
                  >
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'start', flexWrap: 'wrap', gap: '0.5rem', marginBottom: '0.5rem' }}>
                      <h3 style={{ fontSize: '1.25rem', fontWeight: 'bold', margin: 0, color: '#00ffc8' }}>Software Development & Data Analytics</h3>
                      <span style={{ color: '#888', fontSize: '0.875rem' }}>03/2025 - Present</span>
                    </div>
                    <p style={{ color: '#e0e0e0', margin: '0.5rem 0' }}>Faith Mangope Technology and Leadership Institute</p>
                    <p style={{ color: '#888', fontSize: '0.875rem', margin: 0 }}>Azure Cloud Computing • Java OCA • Microsoft Power BI</p>
                    
                    <div className="details" style={{ 
                      maxHeight: '0', 
                      opacity: '0',
                      overflow: 'hidden',
                      transition: 'all 0.5s ease',
                      marginTop: '1rem'
                    }}>
                      <div style={{ 
                        borderTop: '1px solid rgba(0, 255, 200, 0.2)', 
                        paddingTop: '1rem',
                        color: '#e0e0e0',
                        fontSize: '0.9rem',
                        lineHeight: '1.8'
                      }}>
                        <p>Intensive bootcamp focused on enterprise development and data analytics. Currently learning Azure infrastructure, Spring ecosystem deep-dive, and Power BI for data-driven insights.</p>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Wits University */}
                <div style={{ marginBottom: '2rem', position: 'relative' }}>
                  <div style={{
                    position: 'absolute',
                    left: '-2.25rem',
                    top: '0.5rem',
                    width: '16px',
                    height: '16px',
                    borderRadius: '50%',
                    background: '#ff1493',
                    border: '3px solid #0f0f1e',
                    boxShadow: '0 0 20px rgba(255, 20, 147, 0.6)'
                  }} />
                  <div
                    style={{
                      background: 'linear-gradient(135deg, rgba(255, 20, 147, 0.08), rgba(0, 255, 200, 0.05))',
                      padding: '1.5rem',
                      borderRadius: '12px',
                      border: '1px solid rgba(255, 20, 147, 0.2)',
                      cursor: 'pointer',
                      transition: 'all 0.3s ease',
                      overflow: 'hidden'
                    }}
                    onMouseEnter={(e) => {
                      e.currentTarget.style.borderColor = 'rgba(255, 20, 147, 0.5)';
                      e.currentTarget.style.transform = 'scale(1.02)';
                      const details = e.currentTarget.querySelector('.details');
                      if (details) {
                        details.style.maxHeight = '500px';
                        details.style.opacity = '1';
                      }
                    }}
                    onMouseLeave={(e) => {
                      e.currentTarget.style.borderColor = 'rgba(255, 20, 147, 0.2)';
                      e.currentTarget.style.transform = 'scale(1)';
                      const details = e.currentTarget.querySelector('.details');
                      if (details) {
                        details.style.maxHeight = '0';
                        details.style.opacity = '0';
                      }
                    }}
                  >
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'start', flexWrap: 'wrap', gap: '0.5rem', marginBottom: '0.5rem' }}>
                      <h3 style={{ fontSize: '1.25rem', fontWeight: 'bold', margin: 0, color: '#ff1493' }}>BSc Computer Science and Mathematics</h3>
                      <span style={{ color: '#888', fontSize: '0.875rem' }}>02/2022 - 11/2024</span>
                    </div>
                    <p style={{ color: '#e0e0e0', margin: '0.5rem 0' }}>University of Witwatersrand</p>
                    <div style={{
                      background: 'rgba(255, 165, 0, 0.15)',
                      color: '#ffa500',
                      padding: '0.375rem 1rem',
                      borderRadius: '20px',
                      fontSize: '0.875rem',
                      border: '1px solid rgba(255, 165, 0, 0.3)',
                      display: 'inline-block',
                      marginTop: '0.5rem'
                    }}>
                      🏆 Certificate of Merit: Positive Linear Systems III
                    </div>
                    
                    <div className="details" style={{ 
                      maxHeight: '0', 
                      opacity: '0',
                      overflow: 'hidden',
                      transition: 'all 0.5s ease',
                      marginTop: '1rem'
                    }}>
                      <div style={{ 
                        borderTop: '1px solid rgba(255, 20, 147, 0.2)', 
                        paddingTop: '1rem',
                        color: '#e0e0e0',
                        fontSize: '0.9rem',
                        lineHeight: '1.8'
                      }}>
                        <p style={{ marginBottom: '1rem' }}>
                          Rigorous dual-track program combining theoretical computer science with advanced mathematics. This foundation shaped my approach to problem-solving: always understand the math before optimizing.
                        </p>
                        <p>
                          <strong style={{ color: '#00ffc8' }}>Core Coursework:</strong> Software Design, Operating Systems, Algorithms, Data Structures, Databases, Networks, Abstract Algebra, Real Analysis.
                        </p>
                      </div>
                    </div>
                  </div>
                </div>

                {/* High School */}
                <div style={{ position: 'relative' }}>
                  <div style={{
                    position: 'absolute',
                    left: '-2.25rem',
                    top: '0.5rem',
                    width: '16px',
                    height: '16px',
                    borderRadius: '50%',
                    background: '#ffa500',
                    border: '3px solid #0f0f1e',
                    boxShadow: '0 0 20px rgba(255, 165, 0, 0.6)'
                  }} />
                  <div
                    style={{
                      background: 'linear-gradient(135deg, rgba(255, 165, 0, 0.08), rgba(255, 20, 147, 0.05))',
                      padding: '1.5rem',
                      borderRadius: '12px',
                      border: '1px solid rgba(255, 165, 0, 0.2)',
                      cursor: 'pointer',
                      transition: 'all 0.3s ease',
                      overflow: 'hidden'
                    }}
                    onMouseEnter={(e) => {
                      e.currentTarget.style.borderColor = 'rgba(255, 165, 0, 0.5)';
                      e.currentTarget.style.transform = 'scale(1.02)';
                      const details = e.currentTarget.querySelector('.details');
                      if (details) {
                        details.style.maxHeight = '500px';
                        details.style.opacity = '1';
                      }
                    }}
                    onMouseLeave={(e) => {
                      e.currentTarget.style.borderColor = 'rgba(255, 165, 0, 0.2)';
                      e.currentTarget.style.transform = 'scale(1)';
                      const details = e.currentTarget.querySelector('.details');
                      if (details) {
                        details.style.maxHeight = '0';
                        details.style.opacity = '0';
                      }
                    }}
                  >
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'start', flexWrap: 'wrap', gap: '0.5rem', marginBottom: '0.5rem' }}>
                      <h3 style={{ fontSize: '1.25rem', fontWeight: 'bold', margin: 0, color: '#ffa500' }}>National Senior Certificate</h3>
                      <span style={{ color: '#888', fontSize: '0.875rem' }}>01/2017 - 12/2021</span>
                    </div>
                    <p style={{ color: '#e0e0e0', margin: 0 }}>Leap Science and Maths School</p>
                    
                    <div className="details" style={{ 
                      maxHeight: '0', 
                      opacity: '0',
                      overflow: 'hidden',
                      transition: 'all 0.5s ease',
                      marginTop: '1rem'
                    }}>
                      <div style={{ 
                        borderTop: '1px solid rgba(255, 165, 0, 0.2)', 
                        paddingTop: '1rem',
                        color: '#e0e0e0',
                        fontSize: '0.9rem',
                        lineHeight: '1.8'
                      }}>
                        <p>STEM-focused high school with rigorous curriculum in mathematics and sciences. Developed problem-solving foundations that still guide my approach today.</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </section>

          {/* Chapter 3: Skills & Tools */}
          <section ref={el => sectionsRef.current[2] = el} style={{ marginBottom: '6rem' }}>
            <h2 style={{ 
              fontSize: '2.5rem', 
              fontWeight: 'bold', 
              marginBottom: '3rem',
              textAlign: 'center',
              background: 'linear-gradient(135deg, #00ffc8, #ff1493)',
              WebkitBackgroundClip: 'text',
              WebkitTextFillColor: 'transparent'
            }}>
              Skills & Tools
            </h2>

            <div style={{ maxWidth: '900px', margin: '0 auto' }}>
              <div style={{ 
                color: '#e0e0e0', 
                fontSize: '1.125rem', 
                lineHeight: '2',
                background: 'linear-gradient(135deg, rgba(0, 255, 200, 0.08), rgba(255, 20, 147, 0.08))',
                padding: '2rem',
                borderRadius: '16px',
                border: '1px solid rgba(0, 255, 200, 0.2)',
                marginBottom: '3rem',
                textAlign: 'center'
              }}>
                <p style={{ margin: 0 }}>
                  I believe in <strong style={{ color: '#00ffc8' }}>depth over breadth</strong>. I'd rather master a tool deeply than dabble in ten. Here's what I actually know.
                </p>
              </div>

              {skillCategories.map((category, idx) => (
                <div key={idx} style={{ marginBottom: '2.5rem' }}>
                  <h3 style={{ 
                    fontSize: '1.5rem', 
                    fontWeight: 'bold', 
                    marginBottom: '1.5rem', 
                    color: '#00ffc8',
                    display: 'flex',
                    alignItems: 'center',
                    gap: '0.5rem'
                  }}>
                    {category.title}
                    <span style={{ 
                      fontSize: '0.75rem', 
                      background: 'rgba(0, 255, 200, 0.2)', 
                      color: '#00ffc8',
                      padding: '0.25rem 0.75rem',
                      borderRadius: '12px',
                      fontWeight: '600'
                    }}>
                      {category.skills.length}
                    </span>
                  </h3>
                  <div style={{
                    display: 'grid',
                    gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))',
                    gap: '1rem'
                  }}>
                    {category.skills.map((skill, i) => (
                      <div key={i} style={{
                        background: 'linear-gradient(135deg, rgba(0, 255, 200, 0.06), rgba(255, 20, 147, 0.06))',
                        padding: '1rem 1.25rem',
                        borderRadius: '12px',
                        border: '1px solid rgba(0, 255, 200, 0.2)',
                        transition: 'all 0.3s ease',
                        cursor: 'default'
                      }}
                      onMouseEnter={(e) => {
                        e.currentTarget.style.background = 'linear-gradient(135deg, rgba(0, 255, 200, 0.12), rgba(255, 20, 147, 0.12))';
                        e.currentTarget.style.transform = 'translateY(-3px)';
                        e.currentTarget.style.boxShadow = '0 8px 20px rgba(0, 255, 200, 0.15)';
                      }}
                      onMouseLeave={(e) => {
                        e.currentTarget.style.background = 'linear-gradient(135deg, rgba(0, 255, 200, 0.06), rgba(255, 20, 147, 0.06))';
                        e.currentTarget.style.transform = 'translateY(0)';
                        e.currentTarget.style.boxShadow = 'none';
                      }}>
                        <div style={{ 
                          fontSize: '1rem', 
                          fontWeight: '700', 
                          color: '#00ffc8',
                          marginBottom: '0.25rem'
                        }}>
                          {skill.name}
                        </div>
                        <div style={{ 
                          fontSize: '0.875rem', 
                          color: '#888',
                          lineHeight: '1.5'
                        }}>
                          {skill.detail}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </section>

          {/* Chapter 4: The Work */}
          <section ref={el => sectionsRef.current[3] = el} style={{ marginBottom: '6rem' }}>
            <h2 style={{ 
              fontSize: '2.5rem', 
              fontWeight: 'bold', 
              marginBottom: '3rem',
              textAlign: 'center',
              background: 'linear-gradient(135deg, #00ffc8, #ff1493)',
              WebkitBackgroundClip: 'text',
              WebkitTextFillColor: 'transparent'
            }}>
              Building Solutions
            </h2>

            <div style={{ maxWidth: '900px', margin: '0 auto' }}>
              <div style={{ 
                color: '#e0e0e0', 
                fontSize: '1.125rem', 
                lineHeight: '2',
                background: 'linear-gradient(135deg, rgba(0, 255, 200, 0.08), rgba(255, 20, 147, 0.08))',
                padding: '2rem',
                borderRadius: '16px',
                border: '1px solid rgba(0, 255, 200, 0.2)',
                marginBottom: '3rem',
                textAlign: 'center'
              }}>
                <p style={{ margin: 0 }}>
                  Every project started with a real problem. Here's how I solved them with <strong style={{ color: '#00ffc8' }}>clean architecture</strong>, <strong style={{ color: '#ff1493' }}>measurable impact</strong>, and <strong style={{ color: '#00ffc8' }}>honest tradeoffs</strong>.
                </p>
              </div>

              <div style={{ display: 'flex', flexDirection: 'column', gap: '2rem' }}>
                {projects.map((project, idx) => (
                  <EnhancedProjectCard key={idx} {...project} />
                ))}
              </div>
            </div>
          </section>

          {/* Chapter 5: What's Next */}
          <section ref={el => sectionsRef.current[4] = el} style={{ minHeight: '80vh', display: 'flex', flexDirection: 'column', justifyContent: 'center' }}>
            <div style={{ maxWidth: '800px', margin: '0 auto', textAlign: 'center' }}>
              <h2 style={{ 
                fontSize: '3rem', 
                fontWeight: 'bold', 
                marginBottom: '2rem',
                background: 'linear-gradient(135deg, #00ffc8, #ff1493)',
                WebkitBackgroundClip: 'text',
                WebkitTextFillColor: 'transparent'
              }}>
                Let's Build Something
              </h2>
              
              <div style={{ 
                color: '#e0e0e0', 
                fontSize: '1.25rem', 
                lineHeight: '2',
                background: 'linear-gradient(135deg, rgba(0, 255, 200, 0.08), rgba(255, 20, 147, 0.08))',
                padding: '2.5rem',
                borderRadius: '16px',
                border: '1px solid rgba(0, 255, 200, 0.2)',
                marginBottom: '3rem'
              }}>
                <p style={{ marginBottom: '1.5rem' }}>
                  I'm actively seeking opportunities where I can solve real problems, collaborate with sharp teams, and keep learning. I thrive in environments that value <strong style={{ color: '#00ffc8' }}>shipping over perfection</strong>, <strong style={{ color: '#ff1493' }}>impact over activity</strong>, and <strong style={{ color: '#00ffc8' }}>honesty about constraints</strong>.
                </p>
                <p style={{ margin: 0 }}>
                  Whether it's building scalable backend systems, designing intuitive frontends, or optimizing data pipelines—I'm ready to contribute day one. Let's talk about your challenges.
                </p>
              </div>

              <div style={{ 
                display: 'flex', 
                justifyContent: 'center', 
                gap: '1.5rem',
                flexWrap: 'wrap',
                marginBottom: '2rem'
              }}>
                <a
                  href="mailto:athi200308@gmail.com"
                  style={{
                    background: 'linear-gradient(135deg, #00ffc8, #ff1493)',
                    border: 'none',
                    borderRadius: '12px',
                    color: '#0f0f1e',
                    padding: '1rem 2rem',
                    fontSize: '1.125rem',
                    fontWeight: '600',
                    textDecoration: 'none',
                    display: 'inline-flex',
                    alignItems: 'center',
                    gap: '0.75rem',
                    transition: 'all 0.3s ease',
                    boxShadow: '0 10px 30px rgba(0, 255, 200, 0.3)'
                  }}
                  onMouseEnter={(e) => {
                    e.currentTarget.style.transform = 'translateY(-5px)';
                    e.currentTarget.style.boxShadow = '0 15px 40px rgba(0, 255, 200, 0.5)';
                  }}
                  onMouseLeave={(e) => {
                    e.currentTarget.style.transform = 'translateY(0)';
                    e.currentTarget.style.boxShadow = '0 10px 30px rgba(0, 255, 200, 0.3)';
                  }}
                >
                  <Mail size={20} />
                  Get in Touch
                </a>

                <a href="#" 
                  style={{
                    background: 'transparent',
                    border: '2px solid #00ffc8',
                    borderRadius: '12px',
                    color: '#00ffc8',
                    padding: '1rem 2rem',
                    fontSize: '1.125rem',
                    fontWeight: '600',
                    cursor: 'pointer',
                    display: 'inline-flex',
                    alignItems: 'center',
                    gap: '0.75rem',
                    transition: 'all 0.3s ease',
                    textDecoration: 'none'
                  }}
                  onClick={(e) => {
                    e.preventDefault();
                    handleDownloadCV();
                  }}
                  onMouseEnter={(e) => {
                    e.currentTarget.style.background = 'rgba(0, 255, 200, 0.1)';
                    e.currentTarget.style.transform = 'translateY(-5px)';
                  }}
                  onMouseLeave={(e) => {
                    e.currentTarget.style.background = 'transparent';
                    e.currentTarget.style.transform = 'translateY(0)';
                  }}
                >
                  <Download size={20} />
                  Download Resume
                </a>
              </div>

              {/* Social links */}
              <div style={{ display: 'flex', justifyContent: 'center', gap: '1rem', marginBottom: '2rem' }}>
                <a href="https://linkedin.com/in/athini-mgagule-8b8b362b2" target="_blank" rel="noopener noreferrer"
                  style={{ width: '48px', height: '48px', background: '#00ffc8', borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center', transition: 'all 0.3s ease' }}
                  onMouseEnter={(e) => { e.currentTarget.style.transform = 'translateY(-5px)'; e.currentTarget.style.boxShadow = '0 10px 25px rgba(0, 255, 200, 0.5)'; }}
                  onMouseLeave={(e) => { e.currentTarget.style.transform = 'translateY(0)'; e.currentTarget.style.boxShadow = 'none'; }}>
                  <Linkedin size={20} color="#0f0f1e" />
                </a>
                <a href="https://github.com/AthiniMgagule" target="_blank" rel="noopener noreferrer"
                  style={{ width: '48px', height: '48px', background: '#ff1493', borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center', transition: 'all 0.3s ease' }}
                  onMouseEnter={(e) => { e.currentTarget.style.transform = 'translateY(-5px)'; e.currentTarget.style.boxShadow = '0 10px 25px rgba(255, 20, 147, 0.5)'; }}
                  onMouseLeave={(e) => { e.currentTarget.style.transform = 'translateY(0)'; e.currentTarget.style.boxShadow = 'none'; }}>
                  <Github size={20} color="#0f0f1e" />
                </a>
                <a href="https://athinimgagule.netlify.app" target="_blank" rel="noopener noreferrer"
                  style={{ width: '48px', height: '48px', background: '#ffa500', borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center', transition: 'all 0.3s ease' }}
                  onMouseEnter={(e) => { e.currentTarget.style.transform = 'translateY(-5px)'; e.currentTarget.style.boxShadow = '0 10px 25px rgba(255, 165, 0, 0.5)'; }}
                  onMouseLeave={(e) => { e.currentTarget.style.transform = 'translateY(0)'; e.currentTarget.style.boxShadow = 'none'; }}>
                  <Globe size={20} color="#0f0f1e" />
                </a>
              </div>

              <p style={{ 
                marginTop: '3rem', 
                color: '#666', 
                fontSize: '0.875rem',
                fontStyle: 'italic'
              }}>
                "Simplicity is the ultimate sophistication." — Leonardo da Vinci
              </p>
            </div>
          </section>
        </div>

        <style>
          {`
            @keyframes float {
              0%, 100% { transform: translateY(0px); }
              50% { transform: translateY(-20px); }
            }

            @keyframes pulse {
              0%, 100% { opacity: 1; }
              50% { opacity: 0.5; }
            }
            
            * {
              box-sizing: border-box;
            }
            
            body {
              margin: 0;
              background: #0f0f1e;
            }
            
            html {
              scroll-behavior: smooth;
            }

            ::-webkit-scrollbar {
              width: 10px;
            }

            ::-webkit-scrollbar-track {
              background: #1a1a2e;
            }

            ::-webkit-scrollbar-thumb {
              background: linear-gradient(180deg, #00ffc8, #ff1493);
              border-radius: 5px;
            }

            ::-webkit-scrollbar-thumb:hover {
              background: linear-gradient(180deg, #00ffc8, #ff1493);
              filter: brightness(1.2);
            }
          `}
        </style>
      </div>
    );
};

export default EnhancedPortfolio;

  
  
  
  
  
  
  const projects = [
    {
      title: 'ApplyConnect',
      period: 'Ongoing',
      hero:'',
      codeUrl:'',
      videoDemo: '',
      caseStudy:{}
    },
    {
      title: 'Car Rental Management System',
      period: 'Ongoing',
      hero:'',
      codeUrl:'',
      videoDemo: '',
      caseStudy:{}
    },
    {
      title: 'Bank Management System',
      period: 'Ongoing',
      hero:'',
      codeUrl:'',
      videoDemo: '',
      caseStudy:{}
    },
    {
      title: 'URL Shortener',
      period: '08/2025 - 09/2025',
      hero: '/images/url_shortener.png',
      badges: ['Full-stack', 'Spring Boot'],
      codeUrl: 'https://github.com/AthiniMgagule/URLShortener',
      videoDemo: '/videos/Url_Shortener.mp4',
      caseStudy: {
        problem: 'Long URLs are difficult to share and remember, especially in marketing and social media contexts where character limits and aesthetics matter.',
        solution: 'Built a full-stack URL shortening service with collision-resistant hashing, MySQL optimization for sub-50ms redirects, and a clean React interface for URL management.',
        role: 'Solo full-stack developer — architected the backend shortening algorithm using Base62 encoding, built RESTful API with Spring Boot, designed indexed database schema, and created responsive React frontend.',
        outcome: 'Delivered a production-ready service handling 1000+ shortened URLs with 99.9% uptime. Achieved sub-50ms average redirect time through strategic database indexing.',
        lessons: 'Mastered database indexing strategies for high-performance lookups, implemented collision-resistant hashing with retry logic, and gained deep understanding of REST API design patterns and HTTP redirect mechanisms.',
        challenge: 'Initial approach used sequential IDs which were predictable and easily guessable. Switched to Base62 encoding with collision detection, reducing security risks while maintaining speed.',
        metrics: ['Sub-50ms redirects', '1000+ URLs shortened', 'MySQL indexed lookups', '99.9% uptime'],
        tech: ['React', 'Spring Boot', 'MySQL', 'REST API', 'Base62 Encoding', 'Git'],
      }
    },
    {
      title: 'WriteWisp',
      period: 'Ongoing',
      hero: '/images/write_wisp.png',
      badges: ['Full-stack', 'Product Design'],
      codeUrl: 'https://github.com/AthiniMgagule/WriteWisp',
      videoDemo: '/videos/write_wisp.mp4',
      caseStudy: {
        problem: 'Writers struggle with inconsistent creative flow, scattered drafts across multiple platforms, and lack of structured writing prompts to overcome creative blocks.',
        solution: 'A focused writing app featuring AI-powered prompts, autosave every 5 seconds, version control for drafts, and community features to keep creators motivated and productive.',
        role: 'Full-stack developer and product designer — implemented debounced autosave system, integrated AI prompt API with caching layer, built version control system, designed minimalist UI/UX focused on distraction-free writing.',
        outcome: '150+ drafts created during beta testing with 60% increase in daily writing sessions. Users reported 35% faster creative flow when using AI prompts. Beta testers praised the "invisible" autosave feature.',
        lessons: 'Learned to optimize API calls through debouncing and client-side caching, reducing UI freezes by 85%. Discovered the importance of UX research — early users wanted simplicity over feature bloat.',
        challenge: 'Rate-limited prompt API caused UI freezes when users requested multiple prompts quickly. Implemented 500ms debounce with client-side LRU cache (50 prompts), reducing API calls by 70% and eliminating freezes.',
        metrics: ['4.2k lines of code', 'Autosave every 5s', '35% faster prompt load', '150+ beta drafts', '60% more daily sessions'],
        tech: ['React', 'Node.js', 'SQLite', 'REST API', 'Netlify', 'Render', 'Git'],
      }
    }
  ];